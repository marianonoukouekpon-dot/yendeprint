/* Yendeprint – Scripts (WhatsApp, validation, galerie, devis, animations) */

document.addEventListener('DOMContentLoaded', () => {
  const WHATSAPP_NUMBER = '2250142297777';
  const FORM_ENDPOINT = 'https://formsubmit.co/ajax/yendeprint@gmail.com';

  const header = document.querySelector('.header');
  if (header) {
    window.addEventListener('scroll', () => {
      header.classList.toggle('scrolled', window.scrollY > 20);
    }, { passive: true });
  }

  const toggle = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.nav');
  if (toggle && nav) {
    toggle.addEventListener('click', () => {
      const open = !nav.classList.contains('open');
      toggle.classList.toggle('active', open);
      nav.classList.toggle('open', open);
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
      document.body.style.overflow = open ? 'hidden' : '';
    });
    nav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        toggle.classList.remove('active');
        nav.classList.remove('open');
        toggle.setAttribute('aria-expanded', 'false');
        document.body.style.overflow = '';
      });
    });
  }

  if (!document.querySelector('.whatsapp-float')) {
    const wa = document.createElement('a');
    wa.href = 'https://wa.me/' + WHATSAPP_NUMBER + '?text=' + encodeURIComponent('Bonjour Yendeprint, je souhaite un devis.');
    wa.className = 'whatsapp-float';
    wa.target = '_blank';
    wa.rel = 'noopener noreferrer';
    wa.setAttribute('aria-label', 'Contactez-nous sur WhatsApp');
    wa.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.435 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>';
    document.body.appendChild(wa);
  }

  document.querySelectorAll('.card, .gallery-item, .step, .service-card, .reveal').forEach((el, i) => {
    el.classList.add('reveal');
    el.classList.add('reveal-delay-' + ((i % 4) + 1));
  });

  const io = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        io.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
  document.querySelectorAll('.reveal').forEach(el => io.observe(el));

  function showError(el, msg) {
    if (!el) return;
    el.classList.add('error');
    const group = el.closest('.form-group');
    if (group) {
      group.classList.add('has-error');
      group.classList.remove('is-valid');
      const err = group.querySelector('.error-msg');
      if (err) err.textContent = msg;
    }
  }
  function clearError(el) {
    if (!el) return;
    el.classList.remove('error');
    const group = el.closest('.form-group');
    if (group) {
      group.classList.remove('has-error');
      const err = group.querySelector('.error-msg');
      if (err) err.textContent = '';
    }
  }
  function markValid(el) {
    clearError(el);
    const group = el && el.closest('.form-group');
    if (group) group.classList.add('is-valid');
  }
  function validateName(value) {
    const v = value.trim();
    if (v.length < 2) return 'Nom trop court (min. 2 caractères).';
    if (v.length > 80) return 'Nom trop long (max. 80 caractères).';
    if (!/^[\p{L}\s\-'.]+$/u.test(v)) return 'Caractères non autorisés dans le nom.';
    return '';
  }
  function validateEmail(value) {
    const v = value.trim();
    if (!v) return 'E-mail obligatoire.';
    if (v.length > 120) return 'E-mail trop long.';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v)) return 'Format e-mail invalide.';
    return '';
  }
  function validatePhone(value) {
    if (!value.trim()) return '';
    const digits = value.replace(/[\s.\-()]/g, '');
    if (!/^(\+?33|0)[1-9]\d{8}$/.test(digits) && !/^\+?\d{8,15}$/.test(digits)) {
      return 'Numéro invalide (ex. 06 12 34 56 78).';
    }
    return '';
  }
  function validateMessage(value, min, max) {
    min = min || 10; max = max || 2000;
    const v = value.trim();
    if (v.length < min) return 'Message trop court (min. ' + min + ' caractères).';
    if (v.length > max) return 'Message trop long (max. ' + max + ' caractères).';
    return '';
  }

  const contactForm = document.getElementById('contact-form');
  if (contactForm) {
    const nameEl = contactForm.querySelector('#name');
    const emailEl = contactForm.querySelector('#email');
    const phoneEl = contactForm.querySelector('#phone');
    const messageEl = contactForm.querySelector('#message');
    const subjectEl = contactForm.querySelector('#subject');

    if (messageEl) {
      let counter = messageEl.parentElement.querySelector('.char-count');
      if (!counter) {
        counter = document.createElement('div');
        counter.className = 'char-count';
        messageEl.parentElement.appendChild(counter);
      }
      const updateCount = () => {
        const n = messageEl.value.length;
        counter.textContent = n + ' / 2000';
        counter.style.color = n > 2000 ? 'var(--error)' : (n >= 10 ? 'var(--success)' : 'var(--text-muted)');
      };
      messageEl.addEventListener('input', updateCount);
      updateCount();
    }

    const bindLive = (el, validator) => {
      if (!el) return;
      el.addEventListener('blur', () => {
        const err = validator(el.value);
        if (err) showError(el, err);
        else if (el.value.trim()) markValid(el);
        else clearError(el);
      });
      el.addEventListener('input', () => {
        if (el.classList.contains('error') || el.closest('.form-group')?.classList.contains('has-error')) {
          const err = validator(el.value);
          if (err) showError(el, err);
          else markValid(el);
        }
      });
    };
    bindLive(nameEl, validateName);
    bindLive(emailEl, validateEmail);
    bindLive(phoneEl, validatePhone);
    bindLive(messageEl, function(v) { return validateMessage(v, 10, 2000); });
    if (subjectEl) {
      subjectEl.addEventListener('change', () => {
        if (!subjectEl.value) showError(subjectEl, 'Veuillez sélectionner un sujet.');
        else markValid(subjectEl);
      });
    }

    contactForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      let valid = true;
      contactForm.querySelectorAll('.form-group').forEach(g => g.classList.remove('has-error', 'is-valid'));
      const nameErr = validateName(nameEl?.value || '');
      const emailErr = validateEmail(emailEl?.value || '');
      const phoneErr = validatePhone(phoneEl?.value || '');
      const msgErr = validateMessage(messageEl?.value || '', 10, 2000);
      if (nameErr) { showError(nameEl, nameErr); valid = false; } else markValid(nameEl);
      if (emailErr) { showError(emailEl, emailErr); valid = false; } else markValid(emailEl);
      if (phoneErr) { showError(phoneEl, phoneErr); valid = false; }
      else if (phoneEl?.value.trim()) markValid(phoneEl);
      if (subjectEl && !subjectEl.value) { showError(subjectEl, 'Veuillez sélectionner un sujet.'); valid = false; }
      else if (subjectEl) markValid(subjectEl);
      if (msgErr) { showError(messageEl, msgErr); valid = false; } else markValid(messageEl);
      if (!valid) return;
      const gotcha = contactForm.querySelector('[name="_gotcha"]');
      if (gotcha && gotcha.value) return;
      const subjectHidden = contactForm.querySelector('input[name="_subject"]');
      const selectedSubject = subjectEl ? (subjectEl.value || 'Commande') : 'Commande';
      if (subjectHidden) subjectHidden.value = '[Yendeprint] ' + selectedSubject;
      if (window.location.protocol === 'file:') {
        alert('Pour envoyer le formulaire, hébergez le site en ligne ou utilisez un serveur local (http://).');
        return;
      }
      const submitBtn = contactForm.querySelector('#contact-submit');
      const originalLabel = submitBtn ? submitBtn.textContent : 'Envoyer';
      if (submitBtn) { submitBtn.disabled = true; submitBtn.textContent = 'Envoi en cours…'; }
      try {
        const formData = new FormData(contactForm);
        const standardizedMessage = [
          'Bonjour Yendeprint,',
          '',
          'Je souhaite commander ce service.',
          '',
          'Nom : ' + (nameEl?.value || '').trim(),
          'Email : ' + (emailEl?.value || '').trim(),
          'Téléphone : ' + (phoneEl?.value || '').trim(),
          'Sujet : ' + selectedSubject,
          '',
          'Détails du projet :',
          (messageEl?.value || '').trim()
        ].join('\n');
        formData.set('message', standardizedMessage);
        formData.set('_subject', '[Yendeprint] ' + selectedSubject);
        const res = await fetch(FORM_ENDPOINT, { method: 'POST', headers: { Accept: 'application/json' }, body: formData });
        let data = {};
        try { data = await res.json(); } catch (_) {}
        if (res.ok || data.success === 'true' || data.success === true) {
          contactForm.style.display = 'none';
          document.getElementById('form-success')?.classList.add('show');
        } else contactForm.submit();
      } catch (_) {
        if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = originalLabel; }
        contactForm.submit();
      }
    });
  }

  const galleryItems = [...document.querySelectorAll('.gallery-item')];
  galleryItems.forEach(item => {
    if (!item.querySelector('.zoom-icon')) {
      const z = document.createElement('div');
      z.className = 'zoom-icon';
      z.innerHTML = '🔍';
      z.setAttribute('aria-hidden', 'true');
      item.appendChild(z);
    }
  });

  const galleryEmpty = document.getElementById('gallery-empty');
  function applyGalleryFilter(cat) {
    let visibleCount = 0;
    galleryItems.forEach(item => {
      const itemCat = item.dataset.category || 'all';
      const show = cat === 'all' || itemCat === cat;
      item.style.display = show ? '' : 'none';
      if (show) {
        visibleCount++;
        item.classList.remove('visible');
        requestAnimationFrame(() => item.classList.add('visible'));
      }
    });
    if (galleryEmpty) galleryEmpty.hidden = visibleCount > 0;
  }
  const filters = document.querySelector('.gallery-filters');
  if (filters) {
    filters.addEventListener('click', (e) => {
      const btn = e.target.closest('button');
      if (!btn) return;
      filters.querySelectorAll('button').forEach(b => {
        b.classList.remove('active');
        b.setAttribute('aria-pressed', 'false');
      });
      btn.classList.add('active');
      btn.setAttribute('aria-pressed', 'true');
      applyGalleryFilter(btn.dataset.filter || 'all');
    });
  }
  document.querySelectorAll('.service-link[data-filter]').forEach(link => {
    link.addEventListener('click', () => {
      const cat = link.dataset.filter;
      if (!filters || !cat) return;
      const btn = filters.querySelector('[data-filter="' + cat + '"]');
      if (btn) btn.click();
      const gal = document.getElementById('galerie');
      if (gal) gal.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
  });

  let lightbox = document.querySelector('.lightbox');
  if (!lightbox && galleryItems.length) {
    lightbox = document.createElement('div');
    lightbox.className = 'lightbox';
    lightbox.innerHTML = '<div class="lightbox-inner"><button type="button" class="lightbox-close" aria-label="Fermer">&times;</button><button type="button" class="lightbox-nav lightbox-prev" aria-label="Précédent">‹</button><button type="button" class="lightbox-nav lightbox-next" aria-label="Suivant">›</button><img src="" alt=""><div class="lightbox-caption"></div></div>';
    document.body.appendChild(lightbox);
  }
  let lbIndex = 0;
  const visibleItems = () => galleryItems.filter(i => i.style.display !== 'none');
  function openLightbox(index) {
    const items = visibleItems();
    if (!items.length || !lightbox) return;
    lbIndex = (index + items.length) % items.length;
    const item = items[lbIndex];
    const img = item.querySelector('img');
    const caption = item.querySelector('.gallery-overlay span')?.textContent || img?.alt || '';
    const lbImg = lightbox.querySelector('img');
    lbImg.src = img?.src || '';
    lbImg.alt = caption;
    lightbox.querySelector('.lightbox-caption').textContent = caption;
    lightbox.classList.add('open');
    document.body.style.overflow = 'hidden';
  }
  function closeLightbox() {
    lightbox?.classList.remove('open');
    document.body.style.overflow = '';
  }
  galleryItems.forEach((item, i) => {
    const openFromItem = () => {
      const items = visibleItems();
      const idx = items.indexOf(item);
      openLightbox(idx >= 0 ? idx : i);
    };
    item.addEventListener('click', openFromItem);
    item.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        openFromItem();
      }
    });
  });
  if (lightbox) {
    lightbox.querySelector('.lightbox-close')?.addEventListener('click', closeLightbox);
    lightbox.querySelector('.lightbox-prev')?.addEventListener('click', (e) => { e.stopPropagation(); openLightbox(lbIndex - 1); });
    lightbox.querySelector('.lightbox-next')?.addEventListener('click', (e) => { e.stopPropagation(); openLightbox(lbIndex + 1); });
    lightbox.addEventListener('click', (e) => { if (e.target === lightbox) closeLightbox(); });
    document.addEventListener('keydown', (e) => {
      if (!lightbox.classList.contains('open')) return;
      if (e.key === 'Escape') closeLightbox();
      if (e.key === 'ArrowLeft') openLightbox(lbIndex - 1);
      if (e.key === 'ArrowRight') openLightbox(lbIndex + 1);
    });
  }

  /* FAQ accordéon */
  document.querySelectorAll('.faq-question').forEach(btn => {
    btn.addEventListener('click', () => {
      const item = btn.closest('.faq-item');
      const answer = item?.querySelector('.faq-answer');
      if (!item || !answer) return;
      const isOpen = item.classList.contains('is-open');
      document.querySelectorAll('.faq-item.is-open').forEach(openItem => {
        if (openItem === item) return;
        openItem.classList.remove('is-open');
        const q = openItem.querySelector('.faq-question');
        const a = openItem.querySelector('.faq-answer');
        if (q) q.setAttribute('aria-expanded', 'false');
        if (a) a.hidden = true;
      });
      item.classList.toggle('is-open', !isOpen);
      btn.setAttribute('aria-expanded', !isOpen ? 'true' : 'false');
      answer.hidden = isOpen;
    });
  });

  /* Bouton retour en haut */
  if (!document.querySelector('.back-to-top')) {
    const topBtn = document.createElement('button');
    topBtn.type = 'button';
    topBtn.className = 'back-to-top';
    topBtn.setAttribute('aria-label', 'Retour en haut de page');
    topBtn.innerHTML = '↑';
    document.body.appendChild(topBtn);
    const onScroll = () => {
      topBtn.classList.toggle('visible', window.scrollY > 400);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
    topBtn.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

});

